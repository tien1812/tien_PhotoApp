package vn.tien.nvtimage.data.model;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("id")
    private int mId;
    @SerializedName("name")
    private String mName;
    @SerializedName("links")
    private Link mLink;
    @SerializedName("profile_image")
    private ProfileImage mImage;

    public User() {
    }

    public int getId() {
        return mId;
    }

    public String getName() {
        return mName;
    }

    public Link getLink() {
        return mLink;
    }

    public ProfileImage getImage() {
        return mImage;
    }
}
