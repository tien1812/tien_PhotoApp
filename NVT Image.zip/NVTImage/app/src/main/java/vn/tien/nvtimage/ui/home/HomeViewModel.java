package vn.tien.nvtimage.ui.home;

import android.content.Context;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import vn.tien.nvtimage.data.model.Photo;
import vn.tien.nvtimage.data.repository.PhotoRepository;

public class HomeViewModel extends ViewModel {
    private MutableLiveData<List<Photo>> mPhotos;
    private CompositeDisposable mCompositeDisposable;
    private PhotoRepository mRepository;
    private Context mContext;

    public void initViewModel(Context context){
        mCompositeDisposable = new CompositeDisposable();
        mRepository = PhotoRepository.getInstance(context);
        mContext = context;
    }

    public LiveData<List<Photo>> getPhotos(int page){
        mPhotos = new MutableLiveData<>();
        loadPhotos(page);
        return mPhotos;
    }

    private void loadPhotos(int page) {
        Disposable disposable = mRepository.getPhoto(page)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<List<Photo>>() {
                               @Override
                               public void accept(List<Photo> reponse) throws Exception {
                                   mPhotos.setValue(reponse);
                               }
                           },
                        error -> Toast.makeText(mContext, error.getMessage(), Toast.LENGTH_SHORT).show());
        mCompositeDisposable.add(disposable);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        mCompositeDisposable.dispose();
    }
}
