package vn.tien.nvtimage.data.model;

public class ProfileImage {
}
